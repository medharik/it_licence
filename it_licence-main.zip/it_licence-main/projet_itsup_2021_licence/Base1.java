package projet_itsup_2021_licence;

public class Base1 {

public static void main(String[] args) {
	System.out.println("mon premier programme en java ");

	
	
	//les variables : zones memoires reservees lors de la declaration
	
//	byte b=3;
//	short s=10;
//	int i=7000;
//	long l=9999999;
//	 b=(byte) i;//cast 
//	System.out.println("b est "+b);
	int i=3;
	short s=10;
	i=s;
	s=(short)i;
	System.out.println("s est "+s);
	
	
	
	
	
	/*
	 test
	 test 
	 
	 */
	
	
	
	
	
}	  
}
